"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_actualizaciones_actualizaciones_module_ts"],{

/***/ 3547:
/*!*******************************************************************!*\
  !*** ./src/app/actualizaciones/actualizaciones-routing.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ActualizacionesPageRoutingModule": () => (/* binding */ ActualizacionesPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _actualizaciones_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./actualizaciones.page */ 2541);




const routes = [
    {
        path: '',
        component: _actualizaciones_page__WEBPACK_IMPORTED_MODULE_0__.ActualizacionesPage
    }
];
let ActualizacionesPageRoutingModule = class ActualizacionesPageRoutingModule {
};
ActualizacionesPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ActualizacionesPageRoutingModule);



/***/ }),

/***/ 3193:
/*!***********************************************************!*\
  !*** ./src/app/actualizaciones/actualizaciones.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ActualizacionesPageModule": () => (/* binding */ ActualizacionesPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _actualizaciones_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./actualizaciones-routing.module */ 3547);
/* harmony import */ var _actualizaciones_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./actualizaciones.page */ 2541);







let ActualizacionesPageModule = class ActualizacionesPageModule {
};
ActualizacionesPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _actualizaciones_routing_module__WEBPACK_IMPORTED_MODULE_0__.ActualizacionesPageRoutingModule
        ],
        declarations: [_actualizaciones_page__WEBPACK_IMPORTED_MODULE_1__.ActualizacionesPage]
    })
], ActualizacionesPageModule);



/***/ }),

/***/ 2541:
/*!*********************************************************!*\
  !*** ./src/app/actualizaciones/actualizaciones.page.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ActualizacionesPage": () => (/* binding */ ActualizacionesPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _actualizaciones_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./actualizaciones.page.html?ngResource */ 4333);
/* harmony import */ var _actualizaciones_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./actualizaciones.page.scss?ngResource */ 8132);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var capacitor_updater__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! capacitor-updater */ 7629);
/* harmony import */ var _capacitor_splash_screen__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @capacitor/splash-screen */ 2239);






const updateNow = (userVersion) => (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(void 0, void 0, void 0, function* () {
    const url = `https://github.com/wearearima/arima-mobile-releases/raw/main/${userVersion}.zip`;
    /*   const version = await CapacitorUpdater.download({
        url: url
      }) */
    capacitor_updater__WEBPACK_IMPORTED_MODULE_2__.CapacitorUpdater.download({
        url: url
    }).then((version) => (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(void 0, void 0, void 0, function* () {
        // show the splashscreen to let the update happen
        _capacitor_splash_screen__WEBPACK_IMPORTED_MODULE_3__.SplashScreen.show();
        yield capacitor_updater__WEBPACK_IMPORTED_MODULE_2__.CapacitorUpdater.set({ version: version.version, versionName: userVersion });
        _capacitor_splash_screen__WEBPACK_IMPORTED_MODULE_3__.SplashScreen.hide(); // in case the set fail, otherwise the new app will have to hide it
    })).catch(error => {
        console.error("Cannot download version ", error);
    });
});
let ActualizacionesPage = class ActualizacionesPage {
    constructor() { }
    ngOnInit() {
    }
    updateNow(userVersion) {
        updateNow(userVersion);
    }
};
ActualizacionesPage.ctorParameters = () => [];
ActualizacionesPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-actualizaciones',
        template: _actualizaciones_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_actualizaciones_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ActualizacionesPage);



/***/ }),

/***/ 7274:
/*!***********************************************************************!*\
  !*** ./node_modules/@capacitor/splash-screen/dist/esm/definitions.js ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/// <reference types="@capacitor/cli" />



/***/ }),

/***/ 2239:
/*!*****************************************************************!*\
  !*** ./node_modules/@capacitor/splash-screen/dist/esm/index.js ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SplashScreen": () => (/* binding */ SplashScreen)
/* harmony export */ });
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @capacitor/core */ 5099);
/* harmony import */ var _definitions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./definitions */ 7274);

const SplashScreen = (0,_capacitor_core__WEBPACK_IMPORTED_MODULE_0__.registerPlugin)('SplashScreen', {
    web: () => __webpack_require__.e(/*! import() */ "node_modules_capacitor_splash-screen_dist_esm_web_js").then(__webpack_require__.bind(__webpack_require__, /*! ./web */ 2177)).then(m => new m.SplashScreenWeb()),
});




/***/ }),

/***/ 8132:
/*!**********************************************************************!*\
  !*** ./src/app/actualizaciones/actualizaciones.page.scss?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhY3R1YWxpemFjaW9uZXMucGFnZS5zY3NzIn0= */";

/***/ }),

/***/ 4333:
/*!**********************************************************************!*\
  !*** ./src/app/actualizaciones/actualizaciones.page.html?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title>Actualizaciones</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-label>Introduzca el número de versión deseado:</ion-label>\n  <ion-item>\n    <ion-input id=\"userVersion\" [(ngModel)]=\"userVersion\" type=\"text\" placeholder=\"Número de versión...\"></ion-input>\n    <ion-button (click)=\"updateNow(userVersion)\">Actualizar</ion-button>\n  </ion-item>\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_actualizaciones_actualizaciones_module_ts.js.map