"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_cuentas_cuentas_module_ts"],{

/***/ 8037:
/*!***************************************************!*\
  !*** ./src/app/cuentas/cuentas-routing.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CuentasPageRoutingModule": () => (/* binding */ CuentasPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _cuentas_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./cuentas.page */ 3717);




const routes = [
    {
        path: '',
        component: _cuentas_page__WEBPACK_IMPORTED_MODULE_0__.CuentasPage
    }
];
let CuentasPageRoutingModule = class CuentasPageRoutingModule {
};
CuentasPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], CuentasPageRoutingModule);



/***/ }),

/***/ 596:
/*!*******************************************!*\
  !*** ./src/app/cuentas/cuentas.module.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CuentasPageModule": () => (/* binding */ CuentasPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _cuentas_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./cuentas-routing.module */ 8037);
/* harmony import */ var _cuentas_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./cuentas.page */ 3717);







let CuentasPageModule = class CuentasPageModule {
};
CuentasPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _cuentas_routing_module__WEBPACK_IMPORTED_MODULE_0__.CuentasPageRoutingModule
        ],
        declarations: [_cuentas_page__WEBPACK_IMPORTED_MODULE_1__.CuentasPage]
    })
], CuentasPageModule);



/***/ }),

/***/ 3717:
/*!*****************************************!*\
  !*** ./src/app/cuentas/cuentas.page.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CuentasPage": () => (/* binding */ CuentasPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _cuentas_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./cuentas.page.html?ngResource */ 3891);
/* harmony import */ var _cuentas_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./cuentas.page.scss?ngResource */ 3983);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _user_crud_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../user-crud.service */ 554);






let CuentasPage = class CuentasPage {
    constructor(userCrudService, alertController) {
        this.userCrudService = userCrudService;
        this.alertController = alertController;
        this.cuentas = [];
        this.nextPage = 0;
        this.pageLimit = -1;
    }
    ngOnInit() {
        this.loadData(false, "");
    }
    loadData(isFirstLoad, event) {
        if (this.pageLimit == -1 || this.nextPage <= this.pageLimit) {
            this.userCrudService.getCuentas(this.nextPage)
                .subscribe((data) => {
                var listaTemportal = data.content;
                for (let i = 0; i < listaTemportal.length; i++) {
                    this.cuentas.push(listaTemportal[i]);
                }
                console.debug(this.cuentas);
                if (isFirstLoad) {
                    event.target.complete();
                }
                this.nextPage = data.number + 1;
                this.pageLimit = data.totalPages;
            }, error => {
                console.error(error);
            });
        }
        else {
            event.target.complete();
        }
    }
    borrarCuenta(cuenta) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                cssClass: 'my-custom-class',
                header: 'Borrar cuenta',
                message: '¿Borrar la cuenta de ' + cuenta.wctemail + '?',
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'cancel',
                        cssClass: 'secondary',
                        id: 'cancel-button',
                        handler: (blah) => {
                            console.debug('Canceled deletion');
                        }
                    }, {
                        text: 'Confirmar',
                        id: 'confirm-button',
                        handler: () => {
                            this.userCrudService.borrarCuenta(cuenta.wctidusuario).subscribe((data) => {
                                var index = this.cuentas.indexOf(cuenta);
                                if (index != -1) {
                                    this.cuentas.splice(index, 1);
                                    console.info('Deleted cuenta with id ' + cuenta.wctidusuario);
                                }
                            }, error => {
                                console.error(error);
                            });
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
};
CuentasPage.ctorParameters = () => [
    { type: _user_crud_service__WEBPACK_IMPORTED_MODULE_2__.UserCrudService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.AlertController }
];
CuentasPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-cuentas',
        template: _cuentas_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_cuentas_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], CuentasPage);



/***/ }),

/***/ 3983:
/*!******************************************************!*\
  !*** ./src/app/cuentas/cuentas.page.scss?ngResource ***!
  \******************************************************/
/***/ ((module) => {

module.exports = "h2 {\n  font-weight: bold;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImN1ZW50YXMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksaUJBQUE7QUFDSiIsImZpbGUiOiJjdWVudGFzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImgyIHtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbn1cbiJdfQ== */";

/***/ }),

/***/ 3891:
/*!******************************************************!*\
  !*** ./src/app/cuentas/cuentas.page.html?ngResource ***!
  \******************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title>Listado de cuentas</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <ion-list>\n    <ion-item-sliding *ngFor=\"let cuenta of cuentas\">\n      <ion-item [routerLink]=\"['details', cuenta.wctidusuario.trim()]\">\n        <ion-icon size=\"large\" slot=\"start\" name=\"person-circle\"></ion-icon> \n        <ion-label>\n          <ion-text>\n            <h2>{{cuenta.wctemail}}</h2>\n            <h3>{{cuenta.wctnombre}} {{cuenta.wctapellido}}</h3>\n          </ion-text>\n        </ion-label>\n      </ion-item>\n  \n      <ion-item-options side=\"end\">\n        <ion-item-option color=\"danger\" (click)=\"borrarCuenta(cuenta)\">Borrar</ion-item-option>\n      </ion-item-options>\n    </ion-item-sliding>\n  </ion-list>\n\n  <ion-infinite-scroll threshold=\"100px\" (ionInfinite)=\"loadData(true, $event)\">\n    <ion-infinite-scroll-content\n      loadingSpinner=\"bubbles\"\n      loadingText=\"Cargando cuentas...\">\n    </ion-infinite-scroll-content>\n  </ion-infinite-scroll>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_cuentas_cuentas_module_ts.js.map